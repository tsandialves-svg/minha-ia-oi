# IA Pro — Guia de instalação e publicação

Este projeto é um produto completo de IA por assinatura: chat com Google Gemini,
login de usuários e cobrança via Mercado Pago (R$100/mês ou R$1000/ano).

## O que você já tem
- `backend/` — o servidor (API, banco de dados, integração com Gemini e Mercado Pago)
- `frontend/public/` — a interface visual (chat + página de planos)

## Passo 1 — Pegar suas chaves

Você precisa de 3 chaves antes de rodar o sistema:

1. **Chave do Gemini**: acesse https://aistudio.google.com/apikey, faça login com sua conta Google e clique em "Create API Key".
2. **Access Token do Mercado Pago**: acesse https://www.mercadopago.com.br/developers/panel/app, crie uma aplicação e copie o "Access Token de produção" (para testar antes, use o "de teste").
3. **JWT_SECRET**: invente uma frase longa e aleatória qualquer (ex: `banana-roxa-planeta-928xkq`). Serve só para proteger os logins.

## Passo 2 — Configurar

Dentro da pasta `backend/`:

```bash
cp .env.example .env
```

Abra o arquivo `.env` e cole suas chaves nos campos correspondentes.

## Passo 3 — Testar no seu computador

Você precisa ter o **Node.js** instalado (baixe em https://nodejs.org, versão LTS).

```bash
cd backend
npm install
npm start
```

Abra o navegador em **http://localhost:3000** — o app vai aparecer.

## Passo 4 — Publicar na internet (Railway — grátis para começar)

1. Crie uma conta em https://railway.app (pode entrar com GitHub).
2. Suba a pasta `ia-pro` inteira para um repositório no GitHub (se não souber, me peça ajuda que eu te guio).
3. No Railway, clique em "New Project" → "Deploy from GitHub repo" → escolha o repositório.
4. Nas configurações do projeto, defina a pasta raiz como `backend`.
5. Em "Variables", adicione as mesmas variáveis do seu `.env` (GEMINI_API_KEY, JWT_SECRET, MP_ACCESS_TOKEN, PUBLIC_URL — essa última você atualiza depois com a URL que o Railway te der).
6. Clique em "Deploy". Em poucos minutos seu site estará no ar com uma URL tipo `https://seu-projeto.up.railway.app`.
7. Volte nas variáveis e atualize `PUBLIC_URL` com essa URL real, e clique em redeploy.

## Passo 5 — Configurar o webhook do Mercado Pago

No painel do Mercado Pago (https://www.mercadopago.com.br/developers/panel), configure a URL de notificações (webhook) como:

```
https://SEU-DOMINIO/api/pagamento/webhook
```

Isso é o que ativa automaticamente o plano do usuário quando o pagamento é aprovado.

## Como o sistema funciona, resumido

- Usuário se cadastra → começa no plano **Gratuito** (10 mensagens/dia).
- Ele clica em "Assinar mensal" ou "Assinar anual" → é redirecionado pro checkout do Mercado Pago.
- Quando paga, o Mercado Pago avisa seu servidor (webhook) → seu banco de dados atualiza o plano dele automaticamente, com data de expiração.
- Passado o prazo (30 ou 365 dias), ele volta a ser tratado como gratuito até renovar.

## Próximos passos que você pode pedir pra mim depois
- Adicionar um painel de administrador para ver todos os usuários e receita
- Trocar o banco SQLite por um banco mais robusto (Postgres) se crescer muito
- Adicionar recuperação de senha por email
- Melhorar o prompt do Gemini para a IA ter uma "personalidade" própria da sua marca
- Adicionar limite de uso mensal em vez de diário
