const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");

const router = express.Router();

// Cadastro de novo usuário
router.post("/cadastro", async (req, res) => {
  const { nome, email, senha } = req.body;

  if (!nome || !email || !senha) {
    return res.status(400).json({ erro: "Preencha nome, email e senha." });
  }
  if (senha.length < 6) {
    return res.status(400).json({ erro: "A senha precisa ter pelo menos 6 caracteres." });
  }

  const jaExiste = db.prepare("SELECT id FROM usuarios WHERE email = ?").get(email);
  if (jaExiste) {
    return res.status(409).json({ erro: "Já existe uma conta com este email." });
  }

  const senhaHash = await bcrypt.hash(senha, 10);
  const resultado = db
    .prepare("INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)")
    .run(nome, email, senhaHash);

  const token = jwt.sign(
    { id: resultado.lastInsertRowid, nome, email },
    process.env.JWT_SECRET,
    { expiresIn: "30d" }
  );

  res.json({ token, usuario: { nome, email, plano: "gratis" } });
});

// Login
router.post("/login", async (req, res) => {
  const { email, senha } = req.body;
  const usuario = db.prepare("SELECT * FROM usuarios WHERE email = ?").get(email);

  if (!usuario) {
    return res.status(401).json({ erro: "Email ou senha incorretos." });
  }

  const senhaCorreta = await bcrypt.compare(senha, usuario.senha_hash);
  if (!senhaCorreta) {
    return res.status(401).json({ erro: "Email ou senha incorretos." });
  }

  const token = jwt.sign(
    { id: usuario.id, nome: usuario.nome, email: usuario.email },
    process.env.JWT_SECRET,
    { expiresIn: "30d" }
  );

  res.json({
    token,
    usuario: { nome: usuario.nome, email: usuario.email, plano: usuario.plano },
  });
});

module.exports = router;
